package com.example.e_cart;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ViewAllActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private GridView gridView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setTitle("All Products");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        int layoutCode = getIntent().getIntExtra("LAYOUTCODE", -1);
        recyclerView = findViewById(R.id.recycler_view);
        gridView = findViewById(R.id.grid_view);
       // layoutCode =1;
        Toast.makeText(this, "Layout Code: "+layoutCode, Toast.LENGTH_SHORT).show();

        if(layoutCode == 0) {

            recyclerView.setVisibility(View.VISIBLE);
            LinearLayoutManager linearLayout = new LinearLayoutManager(this);
            linearLayout.setOrientation(LinearLayoutManager.VERTICAL);
            recyclerView.setLayoutManager(linearLayout);
            List<WishlistModel> wishlistModelList = new ArrayList<>();
            wishlistModelList.add(new WishlistModel(R.drawable.phone1, "Google Anand Phone", 3, "4.3", 1200, "12000", "15000", "Cash on Delivery aAvailable"));
            wishlistModelList.add(new WishlistModel(R.drawable.phone2, "Google Anand Phone", 3, "4.3", 1200, "12000", "15000", "Cash on Delivery aAvailable"));
            wishlistModelList.add(new WishlistModel(R.drawable.phone1, "Google Anand Phone", 3, "4.3", 1200, "12000", "15000", "Cash on Delivery aAvailable"));
            wishlistModelList.add(new WishlistModel(R.drawable.phone3, "Google Pixel Phone", 3, "4.3", 1200, "12000", "15000", "Cash on Delivery aAvailable"));
            wishlistModelList.add(new WishlistModel(R.drawable.phone1, "Google Anand Phone", 3, "4.3", 1200, "12000", "15000", "Cash on Delivery aAvailable"));
            wishlistModelList.add(new WishlistModel(R.drawable.phone2, "Google Anand Phone", 3, "4.3", 1200, "12000", "15000", "Cash on Delivery aAvailable"));
            wishlistModelList.add(new WishlistModel(R.drawable.phone1, "Google Anand Phone", 3, "4.3", 1200, "12000", "15000", "Cash on Delivery aAvailable"));
            wishlistModelList.add(new WishlistModel(R.drawable.phone3, "Google Pixel Phone", 3, "4.3", 1200, "12000", "15000", "Cash on Delivery aAvailable"));

            WishlistAdapter adapter = new WishlistAdapter(wishlistModelList, false );
            recyclerView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        }else if(layoutCode ==1)
        {


        gridView.setVisibility(View.VISIBLE);
        List<HorizontalScrollProductModel>horizontalScrollProductModelList = new ArrayList<>();
        horizontalScrollProductModelList.add(new HorizontalScrollProductModel(R.drawable.phone1,"Redmi 5A","Intel Core Processor","Rs. 5999"));
        horizontalScrollProductModelList.add(new HorizontalScrollProductModel(R.drawable.phone2,"Redmi 5A","Intel Core Processor","Rs. 5999"));
        horizontalScrollProductModelList.add(new HorizontalScrollProductModel(R.drawable.phone3,"Redmi 5A","Intel Core Processor","Rs. 5999"));
        horizontalScrollProductModelList.add(new HorizontalScrollProductModel(R.drawable.phone1,"Redmi 5A","Intel Core Processor","Rs. 5999"));
        horizontalScrollProductModelList.add(new HorizontalScrollProductModel(R.drawable.phone2,"Redmi 5A","Intel Core Processor","Rs. 5999"));
        horizontalScrollProductModelList.add(new HorizontalScrollProductModel(R.drawable.phone3,"Redmi 5A","Intel Core Processor","Rs. 5999"));
        horizontalScrollProductModelList.add(new HorizontalScrollProductModel(R.drawable.phone1,"Redmi 5A","Intel Core Processor","Rs. 5999"));
        horizontalScrollProductModelList.add(new HorizontalScrollProductModel(R.drawable.phone2,"Redmi 5A","Intel Core Processor","Rs. 5999"));
        horizontalScrollProductModelList.add(new HorizontalScrollProductModel(R.drawable.phone3,"Redmi 5A","Intel Core Processor","Rs. 5999"));
        horizontalScrollProductModelList.add(new HorizontalScrollProductModel(R.drawable.phone1,"Redmi 5A","Intel Core Processor","Rs. 5999"));
        horizontalScrollProductModelList.add(new HorizontalScrollProductModel(R.drawable.phone2,"Redmi 5A","Intel Core Processor","Rs. 5999"));
        horizontalScrollProductModelList.add(new HorizontalScrollProductModel(R.drawable.phone3,"Redmi 5A","Intel Core Processor","Rs. 5999"));
        horizontalScrollProductModelList.add(new HorizontalScrollProductModel(R.drawable.phone1,"Redmi 5A","Intel Core Processor","Rs. 5999"));
        horizontalScrollProductModelList.add(new HorizontalScrollProductModel(R.drawable.phone2,"Redmi 5A","Intel Core Processor","Rs. 5999"));
        horizontalScrollProductModelList.add(new HorizontalScrollProductModel(R.drawable.phone3,"Redmi 5A","Intel Core Processor","Rs. 5999"));
        horizontalScrollProductModelList.add(new HorizontalScrollProductModel(R.drawable.phone1,"Redmi 5A","Intel Core Processor","Rs. 5999"));
        horizontalScrollProductModelList.add(new HorizontalScrollProductModel(R.drawable.phone2,"Redmi 5A","Intel Core Processor","Rs. 5999"));
        horizontalScrollProductModelList.add(new HorizontalScrollProductModel(R.drawable.phone3,"Redmi 5A","Intel Core Processor","Rs. 5999"));

         GridProductLayoutAdapter  adapter1 = new GridProductLayoutAdapter(horizontalScrollProductModelList);
        gridView.setAdapter(adapter1);

        }






    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() ==android.R.id.home)
        {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
